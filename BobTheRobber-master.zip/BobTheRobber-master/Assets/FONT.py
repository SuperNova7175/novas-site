import pygame

pygame.font.get_fonts()